#! /bin/bash

g++ main.cpp ./EE_SDL_Linux/lib.cpp -lSDL2 -lSDL2_image -lSDL2_ttf -lSDL2_gfx -o Program.out
